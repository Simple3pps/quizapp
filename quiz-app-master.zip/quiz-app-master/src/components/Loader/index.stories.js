import LoaderComponent from './index';

export default {
  title: 'Components/Loader',
  component: LoaderComponent,
};

export const Loader = () => <LoaderComponent />;
